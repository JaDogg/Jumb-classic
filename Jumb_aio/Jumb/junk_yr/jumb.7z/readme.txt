you need to copy the runtime dll

JaDogg

*****Do not steal any code from this until this project become completly open source